# Textbook IV · Advanced Strings & Word Combinatorics (Ch 01–30) (Offline HTML Edition)

## How to Read Offline

1. Unzip this archive to any folder on your computer or tablet.
2. Open `index.html` (or `strings/index.html`) in any modern web browser (Chrome, Firefox, Safari, or Edge).

## Offline Features Included

- **100% Offline Math Rendering**: Bundled with local KaTeX scripts and WOFF2 fonts (`assets/katex/`), so no internet connection is required to render formulas.
- **Interactive Navigation & Callouts**: Full docked chapter sidebar, table of contents, light/dark mode toggle, and collapsible solution callouts.
- **Offline Full-Text Search**: Press `/` or `f` (or click the search icon in the top navigation bar) to search chapters offline, even when browsing directly via `file://` URLs without a local web server.
